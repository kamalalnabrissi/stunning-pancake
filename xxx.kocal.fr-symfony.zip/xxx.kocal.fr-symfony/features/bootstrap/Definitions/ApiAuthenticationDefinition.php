<?php

declare(strict_types=1);

namespace Features\Definitions;

use App\Manager\UserManager;
use Behat\Behat\Context\Context;
use Features\Services\SharedStorage;

class ApiAuthenticationDefinition implements Context
{
    private $sharedStorage;
    private $userManager;

    public function __construct(SharedStorage $sharedStorage, UserManager $userManager)
    {
        $this->sharedStorage = $sharedStorage;
        $this->userManager   = $userManager;
    }

    /**
     * @Given I am logged as :username
     */
    public function iAmLoggedAs(string $username): void
    {
        $user = $this->userManager->findOneByUsernameOrFail($username);

        $this->sharedStorage->setAuthToken($user->getApiKey());
    }
}
