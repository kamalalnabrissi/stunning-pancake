<?php

declare(strict_types=1);

namespace Features\Definitions;

use App\Manager\UserManager;
use Behat\Behat\Context\Context;

class UserDefinition implements Context
{
    private $userManager;

    public function __construct(UserManager $userManager)
    {
        $this->userManager = $userManager;
    }

    /**
     * @Given I have an user :username with role :role
     */
    public function iHaveAnUserWithRole(string $username, string $role): void
    {
        $this->userManager->createUser($username, $username, [$role]);
    }
}
