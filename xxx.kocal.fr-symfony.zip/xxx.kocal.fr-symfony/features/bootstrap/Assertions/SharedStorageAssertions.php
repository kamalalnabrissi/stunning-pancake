<?php

declare(strict_types=1);

namespace Features\Assertions;

use Assert\Assertion;
use Behat\Behat\Context\Context;
use Features\Services\SharedStorage;

class SharedStorageAssertions implements Context
{
    private $storage;

    public function __construct(SharedStorage $storage)
    {
        $this->storage = $storage;
    }

    /**
     * @Then the saves :firstSaveName and :secondSaveName should be equal
     */
    public function theSavesAndShouldBeEqual(string $firstSaveName, string $secondSaveName): void
    {
        Assertion::eq($this->storage->get($firstSaveName), $this->storage->get($secondSaveName));
    }
}
