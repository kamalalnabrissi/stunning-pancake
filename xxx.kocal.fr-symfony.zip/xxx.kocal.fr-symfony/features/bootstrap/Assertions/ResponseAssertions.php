<?php

declare(strict_types=1);

namespace Features\Assertions;

use Assert\Assertion;
use Behat\Behat\Context\Context;
use Features\Services\SharedStorage;
use JsonPath\JsonObject;

class ResponseAssertions implements Context
{
    private $storage;

    public function __construct(SharedStorage $storage)
    {
        $this->storage = $storage;
    }

    /**
     * @Then the response node with path :path should be equals to :expected
     */
    public function theResponseNodeWithPathShouldBeEqualsTo(string $path, string $expected): void
    {
        $json = new JsonObject($this->storage->getResponseContent());

        Assertion::eq($json->get($path)[0], $expected);
    }

    /**
     * @Then the response node with path :path should be equals to integer :expected
     */
    public function theResponseNodeWithPathShouldBeEqualsToInteger(string $path, int $expected): void
    {
        $json = new JsonObject($this->storage->getResponseContent());

        Assertion::eq($json->get($path)[0], $expected);
    }
}
