<?php

declare(strict_types=1);

namespace Features\Services;

class SharedStorage extends \Symfony\Component\Cache\Simple\ArrayCache
{
    public function setAuthToken(string $authToken): void
    {
        $this->set('auth_token', $authToken);
    }

    public function getAuthToken(): ?string
    {
        return $this->get('auth_token');
    }

    public function setResponseContent(string $content): void
    {
        $this->set('response_content', $content);
    }

    public function getResponseContent(): ?string
    {
        return $this->get('response_content');
    }
}
