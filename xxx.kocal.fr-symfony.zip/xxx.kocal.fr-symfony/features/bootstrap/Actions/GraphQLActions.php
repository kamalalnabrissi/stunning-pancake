<?php

declare(strict_types=1);

namespace Features\Actions;

use Behat\Behat\Context\Context;
use Features\Services\SharedStorage;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\KernelInterface;
use Symfony\Component\Routing\RouterInterface;

class GraphQLActions implements Context
{
    private $storage;
    private $router;
    private $kernel;

    public function __construct(SharedStorage $storage, KernelInterface $kernel, RouterInterface $router)
    {
        $this->storage = $storage;
        $this->kernel  = $kernel;
        $this->router  = $router;
    }

    /**
     * @When I send a GraphQL request which creates a video
     */
    public function iSendAGraphQLRequestWhichCreatesAVideo(): void
    {
        $query = /** @lang GraphQL */
            'mutation CreateVideo($input: CreateVideoInput!) {
                createVideo(input: $input) {
                    id, title, url, thumbnailUrl, duration
                    site { id, name, host }
                    tags { id, tag, slug }
                } 
            }
        ';

        $variables = [
            'input' => [
                'title'        => 'Slut girl with big boobs',
                'url'          => 'https://site.com/video/1234',
                'thumbnailUrl' => 'https://cdn.site.com/thumbnail/video/1234',
                'duration'     => 160,
                'site'         => [
                    'name' => 'YouJizz',
                    'host' => 'https://youjizz.com',
                ],
                'tags'         => [
                    'Girl',
                    'Slut',
                    'Big boobs',
                ],
            ],
        ];

        $this->sendRequest($query, $variables);
    }

    private function sendRequest(string $query, array $variables = []): void
    {
        $uri     = $this->router->generate('overblog_graphql_endpoint');
        $data    = ['query' => $query, 'variables' => json_encode($variables)];
        $request = Request::create($uri, Request::METHOD_POST, $data);

        $request->headers->set('X-AUTH-TOKEN', $this->storage->getAuthToken());

        $response = $this->kernel->handle($request);

        $this->storage->setResponseContent($response->getContent());
    }
}
