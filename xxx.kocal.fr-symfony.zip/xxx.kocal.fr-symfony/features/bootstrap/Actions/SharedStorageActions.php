<?php

declare(strict_types=1);

namespace Features\Actions;

use Behat\Behat\Context\Context;
use Features\Services\SharedStorage;
use JsonPath\JsonObject;

class SharedStorageActions implements Context
{
    private $storage;

    public function __construct(SharedStorage $storage)
    {
        $this->storage = $storage;
    }

    /**
     * @Given I save the response node with path :path under the name :saveName
     */
    public function iSaveTheResponseNodeWithPathUnderTheName(string $path, string $saveName)
    {
        $json = new JsonObject($this->storage->getResponseContent());

        $this->storage->set($saveName, $json->get($path));
    }
}
