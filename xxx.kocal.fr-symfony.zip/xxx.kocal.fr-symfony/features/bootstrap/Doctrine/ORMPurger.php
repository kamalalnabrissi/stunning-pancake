<?php

namespace Features\Doctrine;

use Behat\Behat\Context\Context;
use Doctrine\Common\DataFixtures\Purger\ORMPurger as DoctrineOrmPurger;
use Symfony\Bridge\Doctrine\RegistryInterface;

class ORMPurger implements Context
{
    private $doctrine;

    public function __construct(RegistryInterface $doctrine)
    {
        $this->doctrine = $doctrine;
    }

    /**
     * @BeforeScenario
     */
    public function clearData()
    {
        $connection = $this->doctrine->getManager()->getConnection();
        $purger     = new DoctrineOrmPurger($this->doctrine->getManager());

        $connection->getConfiguration()->setSQLLogger(null);
        $connection->query('SET FOREIGN_KEY_CHECKS=0');
        $purger->purge();
        $connection->query('SET FOREIGN_KEY_CHECKS=1');

        $this->doctrine->getManager()->clear();
    }
}
