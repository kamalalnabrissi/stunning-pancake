const Encore = require('@symfony/webpack-encore');
const webpack = require('webpack');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');

Encore
// the project directory where compiled assets will be stored
  .setOutputPath('public/build/')
  // the public path used by the web server to access the previous directory
  .setPublicPath('/build')
  .cleanupOutputBeforeBuild()
  .configureBabel((babelConfig) => {
    babelConfig.plugins.push('transform-decorators-legacy');
    babelConfig.plugins.push('transform-class-properties');
    babelConfig.plugins.push('syntax-dynamic-import');
  })
  .enableBuildNotifications()
  .enableSourceMaps(!Encore.isProduction())
  .enableVersioning(Encore.isProduction())
  .enableVueLoader()
  .enableSassLoader()
  .enableTypeScriptLoader(function (typeScriptConfigOptions) {
    typeScriptConfigOptions.appendTsSuffixTo = [/\.vue$/];
  })
  .addEntry('js/app', './assets/js/app.js')
  .addStyleEntry('css/app', './assets/css/app.scss')
;

const webpackConfig = Encore.getWebpackConfig();

// Remove old shitty UglifyJsPlugin plugin (not compatible with ES6)
if (Encore.isProduction()) {
  webpackConfig.plugins = webpackConfig.plugins.filter(plugin => !(plugin instanceof webpack.optimize.UglifyJsPlugin));
  webpackConfig.plugins.push(new UglifyJsPlugin());
}

console.log(require('util').inspect(webpackConfig, false, null));

module.exports = webpackConfig;
