<?php
declare(strict_types=1);

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * @ORM\Entity(repositoryClass="App\Repository\TagRepository")
 */
class Tag
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", unique=true)
     */
    private $tag;

    /**
     * @ORM\Column(type="string", unique=true)
     * @Gedmo\Slug(fields={"tag"})
     */
    private $slug;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\Video", mappedBy="tags")
     */
    private $videos;

    public function __construct()
    {
        $this->videos = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTag(): string
    {
        return $this->tag;
    }

    public function setTag(string $tag): void
    {
        $this->tag = trim($tag);
    }

    public function getSlug(): string
    {
        return $this->slug;
    }

    public function getVideos(): Collection
    {
        return $this->videos;
    }
}
