<?php

declare(strict_types=1);

namespace App\Exception;

class UserNotFoundException extends \InvalidArgumentException
{
    public function __construct(string $username)
    {
        parent::__construct(
            sprintf(
                'User with user « %s » not found.',
                $username
            )
        );
    }
}
