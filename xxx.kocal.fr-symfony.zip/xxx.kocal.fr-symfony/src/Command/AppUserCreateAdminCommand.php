<?php

namespace App\Command;

use App\Manager\UserManager;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

class AppUserCreateAdminCommand extends Command
{
    protected static $defaultName = 'app:user:create-admin';

    private $userManager;

    public function __construct(UserManager $userManager)
    {
        parent::__construct();
        $this->userManager = $userManager;
    }

    protected function configure()
    {
        $this
            ->setDescription('Create an admin')
            ->addArgument('username', InputArgument::REQUIRED, 'Username');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $io = new SymfonyStyle($input, $output);

        $username = $input->getArgument('username');
        $password = $io->askHidden('Password?', function ($value) {
            if (mb_strlen($value) < 8) {
                throw new \RuntimeException('Password is too short (8 characters).');
            }

            return $value;
        });

        try {
            $user = $this->userManager->createUser($username, $password, ['ROLE_ADMIN']);
            $io->success(sprintf('The user « %s » has been created successfully.', $user->getUsername()));
        } catch (\Exception $e) {
            $io->error('An error occurred during user creation.');
            $io->error($e->getMessage());
        }
    }
}
