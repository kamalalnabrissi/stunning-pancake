<?php

declare(strict_types=1);

namespace App\Mutation;

use App\Entity\Video;
use App\Manager\SiteManager;
use App\Manager\TagManager;
use App\Manager\VideoManager;
use Overblog\GraphQLBundle\Definition\Resolver\AliasedInterface;
use Overblog\GraphQLBundle\Definition\Resolver\MutationInterface;

class VideoMutation implements MutationInterface, AliasedInterface
{
    private $videoManager;
    private $siteManager;
    private $tagManager;

    public function __construct(VideoManager $videoManager, SiteManager $siteManager, TagManager $tagManager)
    {
        $this->videoManager = $videoManager;
        $this->siteManager  = $siteManager;
        $this->tagManager   = $tagManager;
    }

    public function create(array $input): Video
    {
        $site = $this->siteManager->findOneOrCreate($input['site']['name'], $input['site']['host']);
        $tags = $this->tagManager->findOrCreate($input['tags']);

        $video = $this->videoManager->findOneByUrl($input['url']);

        if ($video === null) {
            $video = $this->videoManager->create(
                $input['title'],
                $input['url'],
                $input['thumbnailUrl'],
                $input['duration'],
                $site,
                $tags
            );
        }

        return $video;
    }

    public static function getAliases()
    {
        return [
            'create' => 'create_video',
        ];
    }
}
