<?php

namespace App\Resolver;

use App\Repository\VideoRepository;
use Doctrine\Common\Collections\Collection;
use Overblog\GraphQLBundle\Definition\Resolver\AliasedInterface;
use Overblog\GraphQLBundle\Definition\Resolver\ResolverInterface;

class VideoResolver implements ResolverInterface, AliasedInterface
{
    private $videoRepository;

    public function __construct(VideoRepository $videoRepository)
    {
        $this->videoRepository = $videoRepository;
    }

    public function paginate(?int $offset = 0, ?int $limit = 20): array
    {
        return $this->videoRepository->findBy([], ['id' => 'DESC'], $limit, $offset);
    }

    public static function getAliases(): array
    {
        return [
            'paginate' => 'paginate_videos',
        ];
    }
}
