<?php

declare(strict_types=1);

namespace App\Manager;

class ApiKeyManager
{
    public const API_KEY_LENGTH = 64;

    public static function generate(): string
    {
        return bin2hex(openssl_random_pseudo_bytes(self::API_KEY_LENGTH / 2));
    }
}
