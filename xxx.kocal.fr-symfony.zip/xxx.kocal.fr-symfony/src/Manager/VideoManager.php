<?php
declare(strict_types=1);

namespace App\Manager;

use App\Entity\Site;
use App\Entity\Video;
use App\Repository\VideoRepository;
use Doctrine\Common\Collections\Collection;
use Knp\Component\Pager\Pagination\PaginationInterface;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Bridge\Doctrine\RegistryInterface;
use Symfony\Component\Validator\Exception\ValidatorException;
use Symfony\Component\Validator\Validator\ValidatorInterface;

class VideoManager
{
    private $doctrine;
    private $validator;
    private $repository;
    private $paginator;

    public function __construct(RegistryInterface $doctrine, ValidatorInterface $validator, VideoRepository $repository, PaginatorInterface $paginator)
    {
        $this->doctrine   = $doctrine;
        $this->validator  = $validator;
        $this->repository = $repository;
        $this->paginator  = $paginator;
    }

    public function findOneByUrl(string $url): ?Video
    {
        return $this->repository->findOneBy(['url' => $url]);
    }

    public function paginate(int $page = 1, int $limit = 40): PaginationInterface
    {
        $page = $page <= 1 ? 1 : $page;
        $limit = $limit <= 1 ? 20 : $limit;

        return $this->paginator->paginate($this->repository->findAllAsQuery(), $page, $limit);
    }

    public function create(string $title, string $url, string $thumbnailUrl, int $duration, Site $site, Collection $tags): Video
    {
        $video = new Video();
        $video->setTitle($title);
        $video->setUrl($url);
        $video->setThumbnailUrl($thumbnailUrl);
        $video->setDuration($duration);
        $video->setSite($site);

        $tags->map(function ($tag) use ($video) {
            $video->addTag($tag);
        });

        $errors = $this->validator->validate($video);

        if ($errors->count() > 0) {
            throw new ValidatorException((string) $errors);
        }

        $em = $this->doctrine->getManager();
        $em->persist($video);
        $em->flush();

        return $video;
    }
}
