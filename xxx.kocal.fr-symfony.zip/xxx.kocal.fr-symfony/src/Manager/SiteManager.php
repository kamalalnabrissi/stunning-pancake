<?php
declare(strict_types=1);

namespace App\Manager;

use App\Entity\Site;
use App\Repository\SiteRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

class SiteManager
{
    private $doctrine;
    private $repository;

    public function __construct(RegistryInterface $doctrine, SiteRepository $repository)
    {
        $this->doctrine   = $doctrine;
        $this->repository = $repository;
    }

    public function findOneOrCreate(string $name, string $host)
    {
        $site = $this->repository->findOneBy([
            'name' => $value = trim($name),
            'host' => $host = trim($host),
        ]);

        if ($site instanceof Site) {
            return $site;
        }

        $site = new Site();
        $site->setName($name);
        $site->setHost($host);

        $em = $this->doctrine->getManager();
        $em->persist($site);
        $em->flush();

        return $site;
    }
}
