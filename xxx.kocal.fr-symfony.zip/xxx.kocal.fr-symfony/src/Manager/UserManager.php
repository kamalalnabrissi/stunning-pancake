<?php

namespace App\Manager;

use App\Entity\User;
use App\Exception\UserNotFoundException;
use App\Repository\UserRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;

class UserManager
{
    private $doctrine;
    private $userPasswordEncoder;
    private $userRepository;

    public function __construct(RegistryInterface $doctrine, UserPasswordEncoderInterface $userPasswordEncoder, UserRepository $userRepository)
    {
        $this->doctrine            = $doctrine;
        $this->userPasswordEncoder = $userPasswordEncoder;
        $this->userRepository      = $userRepository;
    }

    public function createUser(string $username, string $password, array $roles = ['ROLE_USER']): User
    {
        $user = new User();
        $user->setUsername($username);
        $user->setPassword($this->userPasswordEncoder->encodePassword($user, $password));
        $user->setRoles($roles);
        $user->setApiKey(ApiKeyManager::generate());

        $this->doctrine->getManager()->persist($user);
        $this->doctrine->getManager()->flush();

        return $user;
    }

    public function findOneByUsername(string $username): ?User
    {
        return $this->userRepository->findOneBy(['username' => $username]);
    }

    public function findOneByUsernameOrFail(string $username): User
    {
        if (null === $user = $this->findOneByUsername($username)) {
            throw new UserNotFoundException($username);
        }

        return $user;
    }

    public function findOneByApiKey(string $apiKey): ?User
    {
        return $this->userRepository->findOneBy(['apiKey' => $apiKey]);
    }
}
