<?php
declare(strict_types=1);

namespace App\Manager;

use App\Entity\Tag;
use App\Repository\TagRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Symfony\Bridge\Doctrine\RegistryInterface;

class TagManager
{
    private $doctrine;
    private $repository;

    public function __construct(RegistryInterface $doctrine, TagRepository $repository)
    {
        $this->doctrine   = $doctrine;
        $this->repository = $repository;
    }

    public function findOneOrCreate(string $value): Tag
    {
        $tag = $this->repository->findOneBy(['tag' => $value = trim($value)]);

        if ($tag instanceof Tag) {
            return $tag;
        }

        $tag = new Tag();
        $tag->setTag($value);

        $em = $this->doctrine->getManager();
        $em->persist($tag);
        $em->flush();

        return $tag;
    }

    public function findOrCreate(array $tags): Collection
    {
        return (new ArrayCollection($tags))->map(function ($tag) {
            return $this->findOneOrCreate($tag);
        });
    }
}
