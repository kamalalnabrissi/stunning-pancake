<?php

declare(strict_types=1);

namespace App\Controller;

use App\Manager\VideoManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class VideoController extends AbstractController
{
    /**
     * @Route("/videos", name="list_videos")
     * @Route("/", name="home")
     */
    public function listAction(Request $request, VideoManager $videoManager): Response
    {
        $page   = $request->query->getInt('page', 1);
        $videos = $videoManager->paginate($page, 40);
        $videos->setCustomParameters([
            'position' => 'centered',
            'size' => 'large'
        ]);

        return $this->render('videos/list.html.twig', [
            'videos' => $videos,
        ]);
    }
}
