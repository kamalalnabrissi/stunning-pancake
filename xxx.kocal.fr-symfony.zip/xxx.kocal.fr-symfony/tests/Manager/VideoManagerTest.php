<?php

namespace App\Tests\Manager;

use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;

class VideoManagerTest extends KernelTestCase
{
    private $videoManager;
    private $siteManager;
    private $tagManager;

    public function setUp()
    {
        self::bootKernel();

        $this->videoManager = self::$kernel->getContainer()->get('test.App\Manager\VideoManager');
        $this->siteManager  = self::$kernel->getContainer()->get('test.App\Manager\SiteManager');
        $this->tagManager   = self::$kernel->getContainer()->get('test.App\Manager\TagManager');
    }

    public function testCreate()
    {
        $site  = $this->siteManager->findOneOrCreate('YouJizz', 'https://www.youjizz.com');
        $tags  = $this->tagManager->findOrCreate(['Big boobs', 'Lesbian']);
        $video = $this->videoManager->create(
            'Video 1',
            'https://site.com/video/1',
            'https://cdn.site.com/thumbnail/video/1',
            160,
            $site,
            $tags
        );

        $site2  = $this->siteManager->findOneOrCreate('YouJizz', 'https://www.youjizz.com');
        $tags2  = $this->tagManager->findOrCreate(['Lesbian']);
        $video2 = $this->videoManager->create(
            'Video 2',
            'https://site.com/video/2',
            'https://cdn.site.com/thumbnail/video/2',
            160,
            $site2,
            $tags2
        );

        $this->assertEquals($video->getSite(), $video2->getSite());
        $this->assertEquals($video->getTags()->get(1), $video2->getTags()->get(0));
    }
}
