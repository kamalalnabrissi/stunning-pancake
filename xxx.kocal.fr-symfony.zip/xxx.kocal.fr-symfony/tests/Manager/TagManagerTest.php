<?php

namespace App\Tests\Manager;

use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;

class TagManagerTest extends KernelTestCase
{
    private $tagManager;

    public function setUp()
    {
        self::bootKernel();

        $this->tagManager = self::$kernel->getContainer()->get('test.App\Manager\TagManager');
    }

    public function testFindOneOrCreate()
    {
        $tag  = $this->tagManager->findOneOrCreate('boobs');
        $tag2 = $this->tagManager->findOneOrCreate('boobs');

        $this->assertEquals($tag, $tag2);
    }
}
