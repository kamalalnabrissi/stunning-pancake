<?php

namespace App\Tests\Manager;

use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;

class SiteManagerTest extends KernelTestCase
{
    private $siteManager;

    public function setUp()
    {
        $kernel = self::bootKernel();

        $this->siteManager = $kernel->getContainer()->get('test.App\Manager\SiteManager');
    }

    public function testFindOneOrCreate()
    {
        $sitePornhub  = $this->siteManager->findOneOrCreate('Pornhub', 'https://www.pornhub.com');
        $sitePornhub2 = $this->siteManager->findOneOrCreate('Pornhub', 'https://www.pornhub.com');
        $siteYoujizz  = $this->siteManager->findOneOrCreate('YouJizz', 'https://www.youjizz.com');

        $this->assertEquals($sitePornhub, $sitePornhub2);
        $this->assertNotEquals($sitePornhub, $siteYoujizz);
    }
}
