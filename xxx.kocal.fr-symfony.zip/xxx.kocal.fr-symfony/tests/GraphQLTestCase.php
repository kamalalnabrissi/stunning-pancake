<?php

namespace App\Tests;

use Symfony\Bundle\FrameworkBundle\Test\KernelTestCase;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\RouterInterface;

class GraphQLTestCase extends KernelTestCase
{
    /** @var RouterInterface */
    private $router;

    public function setUp()
    {
        self::bootKernel();

        $this->router = self::$kernel->getContainer()->get('router');
    }

    public function sendGraphQLRequest(string $query, array $variable = []): Response
    {
        $uri = $this->router->generate('overblog_graphql_endpoint', [
            'query'     => $query,
            'variables' => json_encode($variable),
        ]);

        return $this->handle($uri);
    }

    private function handle($uri): Response
    {
        $request  = Request::create($uri, Request::METHOD_POST);
        $response = self::$kernel->handle($request);

        return $response;
    }
}
