<?php

namespace App\Tests\Mutation;

use App\Tests\GraphQLTestCase;

class VideoMutationTest extends GraphQLTestCase
{
    public function testCreate()
    {
        // Define query and variables
        $query = /** @lang GraphQL */
            'mutation CreateVideo($input: CreateVideoInput!) {
                createVideo(input: $input) {
                    id, title, url, thumbnailUrl, duration
                    site { id, name, host }
                    tags { id, tag, slug }
                } 
            }';

        $variables = [
            "input" => [
                "title"        => "Video 1",
                "url"          => "https://site.com/video/1234",
                "thumbnailUrl" => "https://cdn.site.com/thumbnail/video/1234",
                "duration"     => 160,
                "site"         => [
                    "name" => "YouJizz",
                    "host" => "https://youjizz.com",
                ],
                "tags"         => [
                    "Girl",
                    "Slut",
                    "Big boobs",
                ],
            ],
        ];

        // Handle response
        $response = $this->sendGraphQLRequest($query, $variables);
        $response = json_decode($response->getContent(), true);
        $response = $response['data']['createVideo'];

        $this->assertArraySubset([
            "title"        => "Video 1",
            "url"          => "https://site.com/video/1234",
            "thumbnailUrl" => "https://cdn.site.com/thumbnail/video/1234",
            "duration"     => 160,
            "site"         => [
                "name" => "YouJizz",
                "host" => "https://youjizz.com",
            ],
            "tags"         => [
                ["tag" => "Girl", "slug" => "girl"],
                ["tag" => "Slut", "slug" => "slut"],
                ["tag" => "Big boobs", "slug" => "big-boobs"],
            ],
        ], $response);

        // Assertions
        $this->assertInternalType('int', $response['id']);
        $this->assertInternalType('int', $response['site']['id']);
        $this->assertInternalType('int', $response['tags'][0]['id']);
        $this->assertInternalType('int', $response['tags'][1]['id']);
        $this->assertInternalType('int', $response['tags'][2]['id']);

        // Re-send same Query with same variables, and it should return an error
        $response = $this->sendGraphQLRequest($query, $variables);
        $response = json_decode($response->getContent(), true);

        // Assertions again :)
        $this->assertContains('A video with the same URL already exists.', $response['errors'][0]['message']);
    }
}
